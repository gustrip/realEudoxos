/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities.service;

import entities.Students;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.json.simple.JSONObject;


/**
 *
 * @author GK
 */
@Stateless
@Path("students")
public class StudentsFacadeREST extends AbstractFacade<Students> {

    @PersistenceContext(unitName = "EudoksosPU")
    private EntityManager em;

    public StudentsFacadeREST() {
        super(Students.class);
    }

    @GET
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Students find(@PathParam("id") Integer id) {
        return super.find(id);
    }
    
    @GET
    @Path("auth/student")
    @Produces (MediaType.APPLICATION_JSON)
    public Students authStudent(@QueryParam("name")String name,
                                @QueryParam("lastname")String lastname,
                                @QueryParam("login")String login ) {
        name=name.toUpperCase();
        lastname=lastname.toUpperCase();
        login=login.toUpperCase();
        
        JSONParser parser = new JSONParser();
        
        if(!(name.isEmpty()&& lastname.isEmpty() && login.isEmpty())){
           login=login.concat("%");
            Query q=this.em.createNamedQuery("Students.authStudent")
                    .setParameter("login", login)
                    .setParameter("name", name)
                    .setParameter("lastname", lastname);
            
            try{
                Students tmp=(Students)q.getSingleResult();
                return tmp;
            
            }
            catch(NoResultException | NonUniqueResultException e){
                return null;
            }
        }
        return null;
    }
    
    @POST
    @Path("update/student")
    @Consumes (MediaType.APPLICATION_JSON)
    @Produces (MediaType.APPLICATION_JSON)
    public Students updateStudent(String student) throws ParseException{
        student=student.toLowerCase();
        JSONParser parser = new JSONParser();
        Object obj = parser.parse(student);
        JSONObject st = (JSONObject)obj;
        
        if(st.containsKey("name") && st.containsKey("lastname") && st.containsKey("email") && st.containsKey("points")){
            String name=st.get("name").toString();
            String lastname=st.get("lastname").toString();
            String email=st.get("email").toString();
            int points=Integer.parseInt(st.get("points").toString());
            Query q=this.em.createNamedQuery("Students.authStudent2")
                    .setParameter("email", email)
                    .setParameter("name", name)
                    .setParameter("lastname", lastname);
            try{
                Students tmp=(Students)q.getSingleResult();
                if(tmp.getPoints()>=points){
                    tmp.setPoints(tmp.getPoints() - points);
                    return tmp;
                }else{
                    tmp.setPoints(0);
                    return tmp;
                }
            }
            catch(NoResultException | NonUniqueResultException e){
                return null;
            }
        }
        return null;
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
}
